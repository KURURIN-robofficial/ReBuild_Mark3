﻿@echo off
setlocal EnableExtensions

title CameraControllerTest Launcher

set "BASE=%~dp0"
set "DATA=%BASE%data"
set "SETUP=%DATA%\setup.exe"
set "BOTH=%DATA%\Setup_VC2010_Both.bat"

echo ==========================================
echo   CameraControllerTest Launcher
echo ==========================================
echo.

REM -------------------------------------------------
REM Check required distribution files
REM -------------------------------------------------
if not exist "%SETUP%" (
    echo [ERROR] data\setup.exe was not found.
    echo.
    echo Expected:
    echo   %SETUP%
    echo.
    pause
    exit /b 1
)

if not exist "%BOTH%" (
    echo [ERROR] data\Setup_VC2010_Both.bat was not found.
    echo.
    echo Expected:
    echo   %BOTH%
    echo.
    pause
    exit /b 1
)

REM -------------------------------------------------
REM Check Visual C++ 2010 runtime installation
REM Installed=1 means the runtime is installed.
REM Check both normal and Wow6432Node locations.
REM -------------------------------------------------
set "X64_INSTALLED=0"
set "X86_INSTALLED=0"

for /f "tokens=3" %%A in ('reg query "HKLM\SOFTWARE\Microsoft\VisualStudio\10.0\VC\Runtimes\x64" /v Installed 2^>nul ^| findstr /i "Installed"') do set "X64_INSTALLED=%%A"
for /f "tokens=3" %%A in ('reg query "HKLM\SOFTWARE\WOW6432Node\Microsoft\VisualStudio\10.0\VC\Runtimes\x86" /v Installed 2^>nul ^| findstr /i "Installed"') do set "X86_INSTALLED=%%A"

REM Some systems expose x86 without Wow6432Node.
if "%X86_INSTALLED%"=="0" (
    for /f "tokens=3" %%A in ('reg query "HKLM\SOFTWARE\Microsoft\VisualStudio\10.0\VC\Runtimes\x86" /v Installed 2^>nul ^| findstr /i "Installed"') do set "X86_INSTALLED=%%A"
)

echo Visual C++ 2010 x64: %X64_INSTALLED%
echo Visual C++ 2010 x86: %X86_INSTALLED%
echo.

REM -------------------------------------------------
REM Both installed -> launch setup.exe.
REM setup.exe itself handles the ClickOnce application:
REM if installed, it launches it; otherwise it installs it.
REM -------------------------------------------------
if "%X64_INSTALLED%"=="1" if "%X86_INSTALLED%"=="1" (
    echo [OK] Both Visual C++ runtimes are installed.
    echo [START] Starting CameraControllerTest...
    echo.
    start "" /wait "%SETUP%"
    set "ERR=%errorlevel%"
    if not "%ERR%"=="0" (
        echo.
        echo [ERROR] setup.exe returned error code %ERR%.
        pause
        exit /b %ERR%
    )
    exit /b 0
)

REM -------------------------------------------------
REM x64 missing only
REM -------------------------------------------------
if not "%X64_INSTALLED%"=="1" if "%X86_INSTALLED%"=="1" (
    echo [INFO] Visual C++ 2010 x64 is missing.
    echo [INFO] Installing x64 only...
    echo.
    winget install --id Microsoft.VCRedist.2010.x64 --exact --silent --accept-package-agreements --accept-source-agreements
    if errorlevel 1 (
        echo.
        echo [ERROR] Failed to install Visual C++ 2010 x64.
        echo Please check that winget is available and the PC has Internet access.
        pause
        exit /b 2
    )
    goto LAUNCH
)

REM -------------------------------------------------
REM x86 missing only
REM -------------------------------------------------
if "%X64_INSTALLED%"=="1" if not "%X86_INSTALLED%"=="1" (
    echo [INFO] Visual C++ 2010 x86 is missing.
    echo [INFO] Installing x86 only...
    echo.
    winget install --id Microsoft.VCRedist.2010.x86 --exact --silent --accept-package-agreements --accept-source-agreements
    if errorlevel 1 (
        echo.
        echo [ERROR] Failed to install Visual C++ 2010 x86.
        echo Please check that winget is available and the PC has Internet access.
        pause
        exit /b 3
    )
    goto LAUNCH
)

REM -------------------------------------------------
REM Neither installed -> use the existing Both.bat
REM -------------------------------------------------
if not "%X64_INSTALLED%"=="1" if not "%X86_INSTALLED%"=="1" (
    echo [INFO] Neither Visual C++ 2010 runtime is installed.
    echo [INFO] Installing both runtimes...
    echo.
    call "%BOTH%"
    if errorlevel 1 (
        echo.
        echo [ERROR] Visual C++ 2010 setup failed.
        pause
        exit /b 4
    )
    goto LAUNCH
)

REM -------------------------------------------------
REM Unexpected state
REM -------------------------------------------------
echo [ERROR] Could not determine the Visual C++ 2010 runtime state.
echo x64=%X64_INSTALLED%
echo x86=%X86_INSTALLED%
pause
exit /b 5

:LAUNCH
echo.
echo [INFO] Checking Visual C++ 2010 installation again...
timeout /t 2 /nobreak >nul

set "X64_INSTALLED=0"
set "X86_INSTALLED=0"

for /f "tokens=3" %%A in ('reg query "HKLM\SOFTWARE\Microsoft\VisualStudio\10.0\VC\Runtimes\x64" /v Installed 2^>nul ^| findstr /i "Installed"') do set "X64_INSTALLED=%%A"
for /f "tokens=3" %%A in ('reg query "HKLM\SOFTWARE\WOW6432Node\Microsoft\VisualStudio\10.0\VC\Runtimes\x86" /v Installed 2^>nul ^| findstr /i "Installed"') do set "X86_INSTALLED=%%A"
if "%X86_INSTALLED%"=="0" (
    for /f "tokens=3" %%A in ('reg query "HKLM\SOFTWARE\Microsoft\VisualStudio\10.0\VC\Runtimes\x86" /v Installed 2^>nul ^| findstr /i "Installed"') do set "X86_INSTALLED=%%A"
)

if not "%X64_INSTALLED%"=="1" (
    echo [ERROR] x64 runtime is still not installed.
    pause
    exit /b 6
)
if not "%X86_INSTALLED%"=="1" (
    echo [ERROR] x86 runtime is still not installed.
    pause
    exit /b 7
)

echo [OK] Both runtimes are now installed.
echo [START] Starting CameraControllerTest...
echo.
start "" /wait "%SETUP%"
set "ERR=%errorlevel%"
if not "%ERR%"=="0" (
    echo.
    echo [ERROR] setup.exe returned error code %ERR%.
    pause
    exit /b %ERR%
)
exit /b 0
