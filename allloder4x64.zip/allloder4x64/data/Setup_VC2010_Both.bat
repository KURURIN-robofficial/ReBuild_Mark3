﻿@echo off
setlocal
title CameraControllerTest - VC++ 2010 Runtime Setup

echo ==========================================
echo  CameraControllerTest
echo  Visual C++ 2010 SP1 Runtime Setup
echo ==========================================
echo.

REM --- Check for Administrator privileges ---
net session >nul 2>&1
if not "%errorlevel%"=="0" (
    echo Administrator privileges are required.
    echo Requesting elevation...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

echo [1/2] Installing Visual C++ 2010 x64...
winget install --id Microsoft.VCRedist.2010.x64 --exact --silent --accept-package-agreements --accept-source-agreements
set X64ERR=%errorlevel%

echo.
echo [2/2] Installing Visual C++ 2010 x86...
winget install --id Microsoft.VCRedist.2010.x86 --exact --silent --accept-package-agreements --accept-source-agreements
set X86ERR=%errorlevel%

echo.
echo ==========================================
echo  Setup finished
echo ==========================================
echo x64 result: %X64ERR%
echo x86 result: %X86ERR%
echo.
echo If both runtimes were already installed, winget may report that no
echo installation was necessary.
echo.
pause
exit /b
